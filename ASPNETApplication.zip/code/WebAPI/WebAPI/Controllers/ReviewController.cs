﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace WebAPI.Controllers
{
    public class ReviewController : ApiController
    {
        DataClasses1DataContext db = new DataClasses1DataContext();

        // GET: api/Review
        public IEnumerable<Review> Get()
        {
            var reviews = db.Reviews;

            return reviews;
        }

        // GET: api/Review/5      
        public IEnumerable<Review> Get(int id)
        {                     
            var reviews = db.Reviews;
            var review = from b in reviews where b.BookId == id select b;
       
            return review;
        }     


        // POST: api/Review
        public int Post([FromBody]Review newReview)
       
        {
            try
            {
                db.Reviews.InsertOnSubmit(newReview);
                db.SubmitChanges();
               
                return newReview.ReviewId;
            }
            catch (Exception ex)
            {                
                return 0;
             
            }
        }

        // PUT: api/Review/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Review/5
        public void Delete(int id)
        {
        }
    }
}
