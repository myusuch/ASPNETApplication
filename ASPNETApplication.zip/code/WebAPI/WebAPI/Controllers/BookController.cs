﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebAPI.Controllers
{
    public class BookController : ApiController
    {
        DataClasses1DataContext db = new DataClasses1DataContext();

        // GET: api/Book
        public IEnumerable<Book> Get()
        {
            var books = db.Books;

            return books;
        }

        // GET: api/Book/5
        public Book Get(int id)
        {
            var books = db.Books;
            var book = from b in books where b.BookId == id select b;
            Book b1 = book.FirstOrDefault();

            return b1;
        }



        // POST: api/Book
        public int Post([FromBody]Book newBook)
        {
            try
            {
                db.Books.InsertOnSubmit(newBook);
                db.SubmitChanges();
                return newBook.BookId;
            }
            catch
            {
                return 0;
            }
        }

        // PUT: api/Book/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Book/5
        public void Delete(int id)
        {
        }
    }
}
