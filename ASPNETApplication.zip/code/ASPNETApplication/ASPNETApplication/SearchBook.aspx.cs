﻿using ASPNETApplication.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASPNETApplication
{
    public partial class SearchBook : System.Web.UI.Page
    {
        HttpClient client = new HttpClient();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void SearchButton1_Click(object sender, EventArgs e)
        {

            if (DropDownList1.SelectedValue == "1")
            {
                searchById();
            }        

            SearchTextBox1.Text = "";        
        }

        private void searchById()
        {
            String id = SearchTextBox1.Text;

            string url = "http://clubbooksapi.azurewebsites.net/api/book/" + id;
            HttpResponseMessage response = client.GetAsync(url).Result;

            if (response.IsSuccessStatusCode)
            {           
                var data = response.Content.ReadAsStringAsync().Result;

                var book = JsonConvert.DeserializeObject<Book>(data);

                if(book == null)
                {
                    Response.Write("<script>alert('There is no book with the ID!') </script>");
                    return;
                }

                BookNameTextBox1.Text = book.Name;             
                ReleaseDateTextBox1.Text = book.ReleaseDate;
                ISBNTextBox2.Text = book.Isbn;

            }
            
            string url2 = "http://clubbooksapi.azurewebsites.net/api/review/" + id;
            HttpResponseMessage response2 = client.GetAsync(url2).Result;

            if (response2 == null)
            {
                Response.Write("<script>alert('There is no book with the ID!') </script>");
                return;
            }

            if (response2.IsSuccessStatusCode)
            {
                var data2 = response2.Content.ReadAsStringAsync().Result;       

                var reviews = JsonConvert.DeserializeObject<List<Review>>(data2);

                string result = null;               

                foreach (var c in reviews)
                {
                    result +=  "By " + c.Reviewer.Substring(0, 20) + "\r\n" +
                        c.ReviewDetail.Substring(0, 20) + "\r\n\r\n";
                }

                ReviewTextBox2.Text = result;
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
