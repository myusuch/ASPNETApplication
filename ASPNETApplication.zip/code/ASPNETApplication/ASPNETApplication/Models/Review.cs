﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ASPNETApplication.Models
{
    [Serializable]
    public class Review
    {
        string reviewer;
        string reviewDetail;
        string date;
        string rating;
        string bookId;


        public Review(string reviewer, string reviewDetail, string date, string rating, string bookId)
        {
            this.Reviewer = reviewer;
            this.ReviewDetail = reviewDetail;
            this.Date = date;
            this.Rating = rating;
            this.BookId = bookId;
        }

        public string Reviewer
        {
            get
            {
                return reviewer;
            }

            set
            {
                reviewer = value;
            }
        }

        public string ReviewDetail
        {
            get
            {
                return reviewDetail;
            }

            set
            {
                reviewDetail = value;
            }
        }

        public string Date
        {
            get
            {
                return date;
            }

            set
            {
                date = value;
            }
        }

        public string Rating
        {
            get
            {
                return rating;
            }

            set
            {
                rating = value;
            }
        }

        public string BookId
        {
            get
            {
                return bookId;
            }

            set
            {
                bookId = value;
            }
        }

       


    }
}