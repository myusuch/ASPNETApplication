﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ASPNETApplication.Models
{
    //[Serializable]
    public class Book
    {

        string bookId;
        string name;
        string releaseDate;
        string isbn;

        public Book(string bookId, string name, string releaseDate, string isbn)
        {
            this.bookId = bookId;
            this.name = name;
            this.releaseDate = releaseDate;
            this.isbn = isbn;
        }

        public string BookId
        {
            get
            {
                return bookId;
            }

            set
            {
                bookId = value;
            }
        }

        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public string ReleaseDate
        {
            get
            {
                return releaseDate;
            }

            set
            {
                releaseDate = value;
            }
        }

        public string Isbn
        {
            get
            {
                return isbn;
            }

            set
            {
                isbn = value;
            }
        }
    }
}