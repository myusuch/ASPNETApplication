﻿using ASPNETApplication.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASPNETApplication
{
    public partial class AddReviewWebForm : System.Web.UI.Page
    {
        HttpClient client = new HttpClient();

        protected void Page_Load(object sender, EventArgs e)
        {

            

            string url1 = "http://clubbooksapi.azurewebsites.net/api/book/";
            HttpResponseMessage response1 = client.GetAsync(url1).Result;

            if (response1.IsSuccessStatusCode)
            {
                var data = response1.Content.ReadAsStringAsync().Result;

                var books = JsonConvert.DeserializeObject<List<Book>>(data);

                GridView1.DataSource = books;
                GridView1.DataBind();
            }        
        }

        protected void AddReview_Click(object sender, EventArgs e)
        {

            int numOfReview;

            if (Session["numOfReview"] == null)
            {
                numOfReview = 1;
            }
            else
            {
                numOfReview = (int)Session["numOfReview"];
            }

            numOfReviewLabel10.Text = numOfReview.ToString();


            String reviewer = ReviewerTextBox1.Text;
            String review = ReviewTextBox2.Text;
            String rating = RatingDropDownList1.SelectedValue.ToString();
            String bookId_text = BookIdTextBox5.Text;

            DateTime thisDay = DateTime.Today;
            string date = thisDay.ToString("d");       

            var bookReviewer = new KeyValuePair<string, string>("Reviewer", reviewer);
            var ReviewDetail = new KeyValuePair<string, string>("ReviewDetail", review);
            var reviewDate = new KeyValuePair<string, string>("Date", date);
            var bookRating = new KeyValuePair<string, string>("Rating", rating);
            var bookId = new KeyValuePair<string, string>("BookId", bookId_text);

            var content = new FormUrlEncodedContent(new[]
            {
                bookReviewer, ReviewDetail, reviewDate, bookRating, bookId
            });

            string url = "http://clubbooksapi.azurewebsites.net/api/review/";
            HttpResponseMessage response = client.PostAsync(url, content).Result;

            Response.Write("<script>alert('New Review is added!!') </script>");

            ReviewerTextBox1.Text = "";
            ReviewTextBox2.Text = "";
            RatingDropDownList1.SelectedIndex = 0;
            BookIdTextBox5.Text = "";

            Session["numOfReview"] = numOfReview + 1;       
        }
    }
}