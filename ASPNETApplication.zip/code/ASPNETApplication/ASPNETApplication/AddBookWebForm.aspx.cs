﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASPNETApplication
{
    public partial class AddBookWebForm : System.Web.UI.Page
    {
        HttpClient client = new HttpClient();

        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            String name = NameTextBox1.Text;
            String date = DateTextBox2.Text;
            String isbn = ISBNTextBox3.Text;
           

            var bookName = new KeyValuePair<string, string>("name", name);
            var bookDate = new KeyValuePair<string, string>("ReleaseDate", date);
            var bookIsbn = new KeyValuePair<string, string>("ISBN", isbn);
                      
            var content = new FormUrlEncodedContent(new[]
            {
                bookName, bookDate, bookIsbn
            });

            string url = "http://clubbooksapi.azurewebsites.net/api/book/";
            HttpResponseMessage response = client.PostAsync(url, content).Result;

            Response.Write("<script>alert('New book is added!!') </script>");

            NameTextBox1.Text = "";
            DateTextBox2.Text = "";
            ISBNTextBox3.Text = "";
        }

        protected void DateTextBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}